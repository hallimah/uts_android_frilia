package com.example.kuis_uts.model;

import com.google.gson.annotations.SerializedName;

@SuppressWarnings("unused")
public class DataModel {

    @SerializedName("kode")
    private String mKode;
    @SerializedName("nama")
    private String mNama;
    @SerializedName("kategori")
    private String mKategori;

    public String getmKode(){
        return mKode;
    }
    public  String getmNama(){
        return mNama;
    }
    public String getmKategori(){
        return mKategori;
    }

    public void setmKode(String kode){
        mKode = kode;
    }
    public void setmNama(String nama){
        mNama = nama;
    }
    public void setmKategori(String kategori){
        mKategori=kategori;
    }

}
