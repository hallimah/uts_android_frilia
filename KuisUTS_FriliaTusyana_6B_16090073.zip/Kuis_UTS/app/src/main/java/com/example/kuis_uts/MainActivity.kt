package com.example.kuis_uts

import android.content.DialogInterface
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.EditText
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import android.util.Log
import android.view.View
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.kuis_uts.api.RestApi
import com.example.kuis_uts.api.RetroServer
import com.example.kuis_uts.model.ResponseModel
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

   EditText kode,nama,kategori;
    Button btnsave,btnTampildata;
    ProgressBar pd;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pd=(ProgressBar)findViewById(R.id.pd);
        pd.setIndeterminate(true);
        pd.setVisibility(View.GONE);

        kode=(EditText)findViewById(R.id.edt_Kode);
        nama=(EditText)findViewById(R.id.edt_Nama);
        kategori=(EditText)findViewById(R.id.edt_Kategori);
        btnTampildata=(Button)findViewById(R.id.btntampildata);
        btnsave = (Button)findViewById(R.id.btn_insertdata);

        Intent data = getIntent();
        final String kodedata=data.getStringExtra("kode");
        if(kodedata != null){
            btnsave.setVisibility(View.GONE);
            btnTampildata.setVisibility(View.GONE);
            kode.setText(data.getStringExtra("kode"));
            nama.setText(data.getStringExtra("nama"));
            kategori.setText(data.getStringExtra("kategori"));
        }

        btnTampildata.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                startActivity(new Intent(MainActivity.this, TampilData.class));
            }
        });

        btnsave.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String skode= kode.getText().toString();
                String sNama= nama.getText().toString();
                String skategori=kategori.getText().tostring();
                if(skode.isEmpty()){
                    kode.setError("kode perlu diisi");
                }else if(snama.isEmpty()){
                    nama.setError("nama perlu diisi");
                }else if(skategori.isEmpty()){
                    kategori.setError("kategori perlu diisi")
                }else{
                    RestApi api = RetroServer.getClient().create(RestApi.class);
                    Call<ResponseModel> sendmak=api.sendMakanan(skode,snama,skategori);
                    sendmak.enqueue(new Callback<ResponseModel>(){
                        @Override
                        public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response){
                            android.util.Log.d("RETRO", "response:" + response.body().toString());
                            String kode = response.body().getKode();

                            if (kode.equals("1")){
                                android.widget.Toast.makeText(com.example.kuis_uts.MainActivity.this, "data berhasil disimpan", android.widget.Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(com.example.kuis_uts.MainActivity.this, com.example.kuis_uts.TampilData.class));
                                kode.getText().clear();
                                nama.getText().clear();
                                kategori.getText().clear();
                            }else{
                                android.widget.Toast.makeText(com.example.kuis_uts.MainActivity.this, android.widget.Toast.LENGTH_SHORT).show();
                            }
                        }
                        @Override
                        public void onFailure(Call<ResponseModel> call, Throwable t){
                            android.util.Log.d("RETRO", "Failure:" + "Gagal Mengirim Request");
                        }
                    });
                }
            }
        });
    }

}
