package com.example.kuis_uts

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import com.example.kuis_uts.api.RestApi
import com.example.kuis_uts.model.ResponseModel
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Response

class TampilData : AppCompatActivity() {
    private RecyclerView mRecycler;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mManager;
    private List<DataModel> mItems= new ArrayList<>();
    ProgressBar pd;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tampil_data)
        pd = (ProgressBar) findViewById (R.id.pd);
        pd.setIndeterminate(true);
        pd.setVisibility(View.VISIBLE);

        mRecycler = (RecyclerView) findViewById (R.id.recyclerTemp);
        mManager = new LinearLayoutManager (this);
        mRecycler.setLayoutManager(mManager);

        RestApi api = RetroServer . getClient ().create(RestApi.class);
        Call<ResponseModel> getdata = api . getMakanan ();
        getdata.enqueue(new Callback < ResponseModel > call, Response<ResponseModel> response) {
            pd.setVisibility(View.GONE);
            Log.d("RETRO", "RESPONSE:" + response.body().getKode());
            mItems = response.body().getResult();
            mAdapter = new RecyclerAdapter (TampilData.this, mItems);
            mRecycler.setAdapter(mAdapter);
        }
        @Override
        public void onFailure(Call<ResponseModel> call, Throwable t) {
            pd.setVisibility(View.GONE);
            Log.d("RETRO", "FAILED:respon gagal");
        }

    }
}
